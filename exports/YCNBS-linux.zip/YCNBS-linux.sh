#!/bin/sh
echo -ne '\033c\033]0;Game_For_A_Cause\a'
base_path="$(dirname "$(realpath "$0")")"
"$base_path/YCNBS-linux" "$@"
